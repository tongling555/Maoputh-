import React from 'react';
import { vipTiersData, earningsCalculationContent, keyObservationsContent, conclusionContent } from './constants';
import VipCard from './components/VipCard';
import AnalysisSection from './components/AnalysisSection';
import { ChartBarIcon } from './components/Icons'; // Changed from HomeIcon

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-800 flex flex-col">
      <header className="bg-blue-700 text-white shadow-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-5 flex items-center justify-between">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center">
            <ChartBarIcon className="w-8 h-8 mr-3 text-blue-300" />
            Infostride - Tiered Analytics
          </h1>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        <section id="vip-tiers" className="mb-12">
          <h2 className="text-3xl font-semibold text-blue-700 mb-8 text-center">
            Platform Tier Overview
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 xl:gap-8">
            {vipTiersData.map((tier) => (
              <VipCard key={tier.id} tier={tier} />
            ))}
          </div>
        </section>

        <AnalysisSection title="How Earnings Are Calculated">
          {earningsCalculationContent}
        </AnalysisSection>

        <AnalysisSection title="Key Observations">
          {keyObservationsContent}
        </AnalysisSection>
        
        <AnalysisSection title="Conclusion">
          {conclusionContent}
        </AnalysisSection>
      </main>

      <footer className="bg-gray-200 text-gray-700 py-6 text-center mt-auto">
        <p>&copy; {new Date().getFullYear()} Infostride Analytics. All rights reserved.</p>
        <p className="text-sm mt-1">Information presented for analytical purposes.</p>
      </footer>
    </div>
  );
};

export default App;