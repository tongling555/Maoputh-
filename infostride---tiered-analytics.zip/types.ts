
export interface VipTier {
  id: string;
  level: number;
  name: string;
  unlockAmount: number;
  dailyOrders: number;
  dailyIncome?: number; // For VIP0
  commissionRate?: number; // For VIP1+
  earnings30Days: number;
  explanation: string;
  colorClass: string; // Tailwind class for specific tier color
}
