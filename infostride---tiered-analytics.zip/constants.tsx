import React from 'react';
import { VipTier } from './types';

// Infostride theme: primary accent color for highlights
const ACCENT_TEXT_COLOR = "text-blue-700"; // Example: for highlighted text in analysis

export const vipTiersData: VipTier[] = [
  {
    id: "Tier1",
    level: 1,
    name: "Tier 1",
    unlockAmount: 55.00,
    dailyOrders: 10,
    commissionRate: 0.02, // 2%
    dailyIncome: 70.00, 
    earnings30Days: 2100.00,
    explanation: "Entry tier with a 2% commission rate. Achieves a daily income of $70.00, totaling $2,100.00 over 30 days.",
    colorClass: "border-blue-600", // Infostride Theme
  },
  {
    id: "Tier2",
    level: 2,
    name: "Tier 2",
    unlockAmount: 99.00,
    dailyOrders: 10,
    commissionRate: 0.03, // 3%
    dailyIncome: 105.00, 
    earnings30Days: 3150.00,
    explanation: "Progressive tier offering a 3% commission. Generates a daily income of $105.00, or $3,150.00 monthly.",
    colorClass: "border-blue-600", // Infostride Theme
  },
  {
    id: "Tier3",
    level: 3,
    name: "Tier 3",
    unlockAmount: 199.00,
    dailyOrders: 10,
    commissionRate: 0.04, // 4%
    dailyIncome: 140.00, 
    earnings30Days: 4200.00,
    explanation: "Mid-level tier with an increased 4% commission. Daily income is $140.00, leading to $4,200.00 over 30 days.",
    colorClass: "border-blue-600", // Infostride Theme
  },
  {
    id: "Tier4",
    level: 4,
    name: "Tier 4",
    unlockAmount: 299.00,
    dailyOrders: 10,
    commissionRate: 0.05, // 5%
    dailyIncome: 175.00, 
    earnings30Days: 5250.00,
    explanation: "Advanced tier providing a 5% commission. Earns $175.00 daily, accumulating to $5,250.00 in 30 days.",
    colorClass: "border-blue-600", // Infostride Theme
  },
  {
    id: "Tier5",
    level: 5,
    name: "Tier 5",
    unlockAmount: 499.00,
    dailyOrders: 10,
    commissionRate: 0.06, // 6%
    dailyIncome: 210.00, 
    earnings30Days: 6300.00,
    explanation: "High-level tier with a 6% commission. Daily income reaches $210.00, for a monthly total of $6,300.00.",
    colorClass: "border-blue-600", // Infostride Theme
  },
  {
    id: "Tier6",
    level: 6,
    name: "Tier 6",
    unlockAmount: 1000.00,
    dailyOrders: 10,
    commissionRate: 0.07, // 7%
    dailyIncome: 245.00, 
    earnings30Days: 7350.00,
    explanation: "Top tier in this range, featuring a 7% commission. Yields $245.00 daily and $7,350.00 over 30 days.",
    colorClass: "border-blue-600", // Infostride Theme
  }
];

const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
};

export const earningsCalculationContent: React.ReactNode = (
  <div className="space-y-4 text-gray-700">
    <p>The earnings for Tiers 1 through 6 are calculated based on the following assumptions:</p>
    <ul className="list-disc list-inside space-y-1 pl-4">
      <li>All Tiers (Tier 1-6) process <strong>10 daily transactions/bookings</strong>.</li>
      <li>Each transaction has a consistent value of <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(350)}</strong>.</li>
      <li>Calculations are based on a <strong>30-day period</strong>.</li>
      <li>The commission rate starts at <strong>2% for Tier 1</strong> and increases by <strong>1% for each subsequent tier</strong>.</li>
    </ul>
    <p>The formula for 30-day commission is: <br/><code className="text-sm bg-gray-200 text-gray-800 px-2 py-1 rounded">Daily Transactions × 30 Days × Per-Transaction Value × Commission Rate</code></p>
    <p>Daily income can be calculated as: <br/><code className="text-sm bg-gray-200 text-gray-800 px-2 py-1 rounded">Daily Transactions × Per-Transaction Value × Commission Rate</code></p>
    
    <div>
      <h4 className="text-lg font-semibold text-gray-800 mb-2">Commission Every 30 Days:</h4>
      <ul className="list-disc list-inside space-y-1 pl-4">
        <li>
          <strong>Tier 1 (2% Commission):</strong> 10 trans./day × 30 days × {formatCurrency(350)}/trans. × 0.02 = <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(2100)}</strong> (Daily: {formatCurrency(70)})
        </li>
        <li>
          <strong>Tier 2 (3% Commission):</strong> 10 trans./day × 30 days × {formatCurrency(350)}/trans. × 0.03 = <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(3150)}</strong> (Daily: {formatCurrency(105)})
        </li>
        <li>
          <strong>Tier 3 (4% Commission):</strong> 10 trans./day × 30 days × {formatCurrency(350)}/trans. × 0.04 = <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(4200)}</strong> (Daily: {formatCurrency(140)})
        </li>
        <li>
          <strong>Tier 4 (5% Commission):</strong> 10 trans./day × 30 days × {formatCurrency(350)}/trans. × 0.05 = <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(5250)}</strong> (Daily: {formatCurrency(175)})
        </li>
        <li>
          <strong>Tier 5 (6% Commission):</strong> 10 trans./day × 30 days × {formatCurrency(350)}/trans. × 0.06 = <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(6300)}</strong> (Daily: {formatCurrency(210)})
        </li>
        <li>
          <strong>Tier 6 (7% Commission):</strong> 10 trans./day × 30 days × {formatCurrency(350)}/trans. × 0.07 = <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(7350)}</strong> (Daily: {formatCurrency(245)})
        </li>
      </ul>
    </div>
  </div>
);

export const keyObservationsContent: React.ReactNode = (
  <div className="space-y-3 text-gray-700">
    <div className="mt-2">
      <h4 className="text-md font-semibold text-gray-800 mb-1">Tier Access Fee Growth:</h4>
      <p>The access fees (previously 'unlock amounts') progress from {formatCurrency(55)} (Tier 1) to {formatCurrency(1000)} (Tier 6). This represents an approximately 18x total increase across these six tiers, with incremental steps (roughly 1.8x to 2x increase per tier) designed to encourage steady progression.</p>
    </div>
    <div>
      <h4 className="text-md font-semibold text-gray-800 mb-1">Commission and Earnings Growth:</h4>
      <p>Daily income ranges from {formatCurrency(70)} (Tier 1) to {formatCurrency(245)} (Tier 6). Monthly earnings scale from {formatCurrency(2100)} (Tier 1) to {formatCurrency(7350)} (Tier 6), a 250% increase in earnings potential. This growth is driven by a 1% increment in the commission rate at each tier, starting from 2% at Tier 1 up to 7% at Tier 6.</p>
    </div>
    <div>
      <h4 className="text-md font-semibold text-gray-800 mb-1">Incentive Balance:</h4>
      <p>The structure appears to balance incentives: lower initial access fees (e.g., {formatCurrency(55)} to {formatCurrency(299)}) can attract new or cautious users/hosts, while the higher tiers ({formatCurrency(499)} and {formatCurrency(1000)}) target more committed participants seeking greater rewards from the platform.</p>
    </div>
  </div>
);

export const conclusionContent: React.ReactNode = (
  <div className="text-gray-700 leading-relaxed space-y-4">
    <p>
      The updated Tier structure (Tier 1-6) outlines a clear progression path with increasing access fees and correspondingly higher commission rates and daily incomes. The sequence of access fees—{formatCurrency(55)}, {formatCurrency(99)}, {formatCurrency(199)}, {formatCurrency(299)}, {formatCurrency(499)}, and {formatCurrency(1000)}—shows a pattern of roughly 1.8x to 2x increase per tier.
    </p>
    <h4 className="text-md font-semibold text-gray-800 mt-3 mb-1">Assumptions & Time Frame:</h4>
     <ul className="list-disc list-inside space-y-1 pl-4">
        <li>The analysis assumes 10 daily transactions per tier.</li>
        <li>Each transaction is valued at <strong className={ACCENT_TEXT_COLOR}>{formatCurrency(350)}</strong>.</li>
        <li>All earnings calculations are based on a 30-day period, with daily income also highlighted.</li>
    </ul>
    <h4 className="text-md font-semibold text-gray-800 mt-3 mb-1">Consideration for Unaddressed Values:</h4>
    <p>
      The originally provided list of values included amounts beyond the six tiers analyzed: {formatCurrency(5999)}, {formatCurrency(19999)}, and {formatCurrency(2999)}. These values were not incorporated into the current Tier 1-6 structure. They could potentially indicate:
    </p>
    <ul className="list-disc list-inside space-y-1 pl-4">
      <li>Additional, higher platform tiers (e.g., Tier 7, Tier 8, Tier 9).</li>
      <li>Alternative values or corrections for the existing tiers.</li>
    </ul>
    <p>
      Further clarification on these amounts would be needed to extend the analysis or adjust the current model. For now, the application reflects the six-tier structure derived from the initial set of values, presented within an Infostride-inspired theme.
    </p>
  </div>
);