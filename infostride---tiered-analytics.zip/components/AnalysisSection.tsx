import React from 'react';

interface AnalysisSectionProps {
  title: string;
  children: React.ReactNode;
}

const AnalysisSection: React.FC<AnalysisSectionProps> = ({ title, children }) => {
  return (
    <div className="bg-white shadow-lg rounded-lg p-6 sm:p-8 mb-8 lg:mb-12">
      <h2 className="text-2xl sm:text-3xl font-semibold text-blue-700 mb-6 pb-4 border-b-2 border-gray-200">
        {title}
      </h2>
      <div className="text-gray-700 leading-relaxed space-y-4">
        {children}
      </div>
    </div>
  );
};

export default AnalysisSection;