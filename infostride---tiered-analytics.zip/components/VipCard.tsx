import React from 'react';
import { VipTier } from '../types';
import { LockOpenIcon, ShoppingCartIcon, PercentIcon, BanknotesIcon, InformationCircleIcon, ArrowTrendingUpIcon } from './Icons';

interface VipCardProps {
  tier: VipTier;
}

const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
};

const VipCard: React.FC<VipCardProps> = ({ tier }) => {
  // Infostride Theme Styles
  const cardBg = 'bg-white text-gray-800';
  const textColor = 'text-gray-600'; // General item text
  const headingColor = 'text-gray-800 font-semibold'; // For main values like amounts
  const tierNameColor = 'text-blue-700'; // Infostride Blue for tier name
  const iconAccentColor = 'text-teal-500'; // Infostride Teal for icons

  const earningsFigureAccentColor = 'text-blue-700 font-bold text-lg';
  const earningsIconColor = iconAccentColor; // Teal for consistency with other icons
  const earningsHighlightBg = 'bg-blue-50'; // Very light blue for earnings box

  return (
    <div className={`rounded-lg shadow-lg overflow-hidden flex flex-col h-full transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${cardBg} border-t-4 ${tier.colorClass}`}>
      <div className="p-5 border-b border-gray-200">
        <h3 className={`text-xl font-bold ${tierNameColor} mb-1`}>{tier.name}</h3>
      </div>

      <div className="p-5 space-y-3 flex-grow">
        <div className="flex items-center">
          <LockOpenIcon className={`w-5 h-5 mr-3 ${iconAccentColor}`} />
          <span className={`${textColor} text-sm`}>Access Fee:</span>
          <span className={`ml-auto ${headingColor} text-sm`}>{formatCurrency(tier.unlockAmount)}</span>
        </div>
        <div className="flex items-center">
          <ShoppingCartIcon className={`w-5 h-5 mr-3 ${iconAccentColor}`} />
          <span className={`${textColor} text-sm`}>Daily Transactions:</span>
          <span className={`ml-auto ${headingColor} text-sm`}>{tier.dailyOrders}</span>
        </div>
        
        {tier.commissionRate !== undefined && (
          <div className="flex items-center">
            <PercentIcon className={`w-5 h-5 mr-3 ${iconAccentColor}`} />
            <span className={`${textColor} text-sm`}>Commission Rate:</span>
            <span className={`ml-auto ${headingColor} text-sm`}>{(tier.commissionRate * 100).toFixed(2)}%</span>
          </div>
        )}
        {tier.dailyIncome !== undefined && (
           <div className="flex items-center">
             <BanknotesIcon className={`w-5 h-5 mr-3 ${iconAccentColor}`} />
             <span className={`${textColor} text-sm`}>Daily Income:</span>
             <span className={`ml-auto ${headingColor} text-sm`}>{formatCurrency(tier.dailyIncome)}</span>
           </div>
        )}

        <div className={`flex items-center p-3 rounded-md ${earningsHighlightBg} mt-2`}>
          <ArrowTrendingUpIcon className={`w-5 h-5 mr-3 ${earningsIconColor}`} />
          <span className={`${textColor} font-medium text-sm`}>Earnings (30 Days):</span>
          <span className={`ml-auto ${earningsFigureAccentColor}`}>{formatCurrency(tier.earnings30Days)}</span>
        </div>
        
        <div className="pt-3 mt-2 border-t border-gray-200">
           <h4 className={`text-sm font-semibold mb-1 flex items-center text-gray-700`}>
             <InformationCircleIcon className={`w-5 h-5 mr-2 ${iconAccentColor}`} />
             Details
           </h4>
          <p className="text-xs leading-relaxed text-gray-500">{tier.explanation}</p>
        </div>
      </div>
    </div>
  );
};

export default VipCard;