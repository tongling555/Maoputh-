import React from 'react';

interface IconProps {
  className?: string;
}

export const LockOpenIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H3.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  </svg>
);

export const ShoppingCartIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
  </svg>
);

export const CogIcon: React.FC<IconProps> = ({ className }) => ( // Representing Commission Rate / Settings
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.343 3.94c.09-.542.56-1.007 1.11-.913l.444.059c.594.078 1.037.49 1.14.948l.056.224c.056.223.11.446.166.669l.06.236c.093.368.04.717-.137.962l-.088.123c-.15.207-.333.39-.527.553l-.078.068c-.302.255-.403.559-.403.816v.149c0 .257.101.562.403.816l.078.068c.194.163.377.346.527.553l.088.123c.177.245.23.594.137.962l-.06.236a5.558 5.558 0 00-.166.669l-.056.224c-.103.458-.546.87-.14.948l-.444.059c-.55.093-1.02-.37-1.11-.913L9.66 18.06c-.056-.224-.11-.447-.166-.67l-.06-.235c-.093-.368-.04-.717.137-.962l.088-.123c.15-.207.333.39.527-.553l.078-.068c.302-.255.403-.559.403.816V12c0-.257-.101-.562-.403-.816l-.078-.068a3.15 3.15 0 01-.527-.553l-.088-.123c-.177-.245-.23-.594-.137-.962l.06-.235c.056-.223.11-.446.166-.669l.056-.224zm3.08.106c.09-.542.56-1.007 1.11-.913l.444.059c.594.078 1.037.49 1.14.948l.056.224c.056.223.11.446.166.669l.06.236c.093.368.04.717-.137.962l-.088.123c-.15.207-.333.39-.527.553l-.078.068c-.302.255-.403.559-.403.816v.149c0 .257.101.562.403.816l.078.068c.194.163.377.346.527.553l.088.123c.177.245.23.594.137.962l-.06.236a5.558 5.558 0 00-.166.669l-.056.224c-.103.458-.546.87-.14.948l-.444.059c-.55.093-1.02-.37-1.11-.913L13.42 18.06c-.056-.224-.11-.447-.166-.67l-.06-.235c-.093-.368-.04-.717.137-.962l.088-.123c.15-.207.333.39.527-.553l.078-.068c.302-.255.403-.559.403.816V12c0-.257-.101-.562-.403-.816l-.078-.068a3.15 3.15 0 01-.527-.553l-.088-.123c-.177-.245-.23-.594-.137-.962l.06-.235c.056-.223.11-.446.166-.669l.056-.224z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15a3 3 0 100-6 3 3 0 000 6z" />
  </svg>
);

export const PercentIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19 5L5 19" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M7 7C8.10457 7 9 6.10457 9 5C9 3.89543 8.10457 3 7 3C5.89543 3 5 3.89543 5 5C5 6.10457 5.89543 7 7 7Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M17 17C18.10457 17 19 16.10457 19 15C19 13.89543 18.10457 13 17 13C15.89543 13 15 13.89543 15 15C15 16.10457 15.89543 17 17 17Z" />
  </svg>
);

export const BanknotesIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v15c0 .621-.504 1.125-1.125 1.125h-15c-.621 0-1.125-.504-1.125-1.125V6.375c0-.621.504-1.125 1.125-1.125h15m1.5 0v2.25M7.5 12h3m0 0h3m-3 0a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const InformationCircleIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
  </svg>
);

export const StarIcon: React.FC<IconProps> = ({ className }) => ( // Kept for potential future use
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354l-4.502 2.825c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
  </svg>
);

export const ArrowTrendingUpIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
  </svg>
);

export const ChartBarIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
  </svg>
);

// Remove HomeIcon if it was still present from previous steps to avoid conflicts
// export const HomeIcon: React.FC<IconProps> = ({ className }) => ( ... );
// Ensure only one definition of each icon exists.
